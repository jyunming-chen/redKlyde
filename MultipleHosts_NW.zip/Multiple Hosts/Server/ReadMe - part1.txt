//***********************************************************************//
//										
//		- "Talk to me like I'm a 3 year old!" Programming Lessons -
//                                                                      
//		$Author:		redKlyde -- redKlyde@gametutorials.com	
//									
//		$Program:		part1			
//									
//		$Description:	Mutliple hosts (server part)
//									
//		$Date:		4/5/03				
//									
//***********************************************************************//

Files:  	server.cpp (The Source File containing the actual code)
	part1.dsp  (The Project File holding the project info)
	part1.dsw  (The Workspace File holding the workspace info)

Instructions:	If you have visual studio c++ (around version 6) just click on the
		<Program Name>.dsw file.  This will open up up visual c++.  You will most
		likely see the code for <Program Name>.cpp.  If you don't, there should be
		a tab on the left window (workspace window) called "FileView".  Click the 
		tab and click on the plus sign in this tab if it isn't already open.
		There you should see 2 folders called "source" and "header".
		Double click on the "source" folder and you should see your source file with
		a .cpp extension after it.  Double click on the file and it will open
		up in your main window.  Hit Control-F5 to run the program.
		You will probably see a prompt to compile/build the project.  Click OK and
		a console window should pop up with the program. :)

EULA:  	Your use of this tutorial constitutes your agreement to GameTutorials' Terms of Use found
	at:  http://www.gametutorials.com/TermsOfUse.htm

www.GameTutorials.com
�2000-2003 GameTutorials